Questo virus può essere potenzialmente pericoloso.
IO non mi assumo nessuna responsabilità.
-
-
-
-
-
CREDITI:<<https://github.com/Matteolive>>
-